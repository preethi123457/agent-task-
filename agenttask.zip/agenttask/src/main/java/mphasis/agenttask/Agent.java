package mphasis.agenttask;

public class Agent {

	private int AgentID;
	private String Name;
	private String City;
	private String Gender;
	private String MaritalStatus;
	private int Premium;
	
	
	
	public int getAgentID() {
		return AgentID;
	}

	public void setAgentID(int agentID) {
		AgentID = agentID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getMaritalStatus() {
		return MaritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		MaritalStatus = maritalStatus;
	}

	public int getPremium() {
		return Premium;
	}

	public void setPremium(int premium) {
		Premium = premium;
	}

	
	@Override
	public String toString() {
		return "Agent [AgentID=" + AgentID + ", Name=" + Name + ", City=" + City + ", Gender=" + Gender
				+ ", MaritalStatus=" + MaritalStatus + ", Premium=" + Premium + "]";
	}

	public Agent() {
		// TODO Auto-generated constructor stub
	}

	public Agent(int agentID, String name, String city, String gender, String maritalStatus, int premium) {
		super();
		AgentID = agentID;
		Name = name;
		City = city;
		Gender = gender;
		MaritalStatus = maritalStatus;
		Premium = premium;
	}


	
}