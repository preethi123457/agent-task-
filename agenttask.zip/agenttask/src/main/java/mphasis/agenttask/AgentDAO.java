package mphasis.agenttask;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class AgentDAO {

	Connection connection;
	PreparedStatement pst;

	public String addAgent(Agent agent) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "insert into Agent(agentID,Name,City,Gender,MaritalStatus,Premium) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, agent.getAgentID());
		pst.setString(2, agent.getName());
		pst.setString(3, agent.getCity());
		pst.setString(4, agent.getGender());
		pst.setString(5, agent.getMaritalStatus());
		pst.setInt(6, agent.getPremium());
		pst.executeUpdate();
		return "Record Inserted...";
	}


	public Agent searchAgent(int AgentID) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Agent where AGENTID=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, AgentID);
		ResultSet rs = pst.executeQuery();
		Agent agent = null;
		if (rs.next()) {
			agent = new Agent();
			agent.setAgentID(rs.getInt("AgentID"));
			agent.setName(rs.getString("Name"));
			agent.setCity(rs.getString("City"));
			agent.setGender(rs.getString("Gender"));
			agent.setMaritalStatus(rs.getString("MaritalStatus"));
			agent.setPremium(rs.getInt("Premium"));
		}
		return agent;
	}


	public Agent[] showAgent() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Agent";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		Agent agent = null;
		List<Agent> agentList = new ArrayList<Agent>();
		while(rs.next()) {
			agent = new Agent();
			agent.setAgentID(rs.getInt("AgentID"));
			agent.setName(rs.getString("Name"));
			agent.setCity(rs.getString("City"));
			agent.setGender(rs.getString("Gender"));
			agent.setMaritalStatus(rs.getString("MaritalStatus"));
			agent.setPremium(rs.getInt("Premium"));
			agentList.add(agent);
		}
		return agentList.toArray(new Agent[agentList.size()]);
	}

	
}