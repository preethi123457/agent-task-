package mphasis.agenttask;

import java.sql.SQLException;


import javax.ws.rs.GET;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/agent")
public class AgentService {
	
	
	@GET
	@Path("/showagent")
	@Produces(MediaType.APPLICATION_JSON)
	public Agent[] showAgent() throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		Agent[] agent = dao.showAgent();
		return agent;
	}
	
	@GET
	@Path("/searchagent/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Agent searchAgent(@PathParam("id") int id) throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		Agent agent = dao.searchAgent(id);
		return agent;
	}
}